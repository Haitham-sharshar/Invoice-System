---
name: "Bug report"
about: "Report something that's broken. Please ensure your Laravel version is still supported: https://github.com/Laravel-Lang/lang#via-composer"
---

<!-- DO NOT THROW THIS AWAY -->
<!-- Fill out the FULL versions with patch versions -->

- Laravel-Lang Version: #.#.#
- PHP Version: #.#.#

### Description:


### Steps To Reproduce:
